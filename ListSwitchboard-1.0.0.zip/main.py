#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=2:sw=2:sta:et:sts=2:ai

__license__ = 'GPL v3'
__copyright__ = '2026, List Switchboard contributors'
__docformat__ = 'restructuredtext en'

import os
import traceback
import time
from urllib.request import Request, urlopen

from qt.core import QApplication, QDialog, QMessageBox

from calibre.gui2 import error_dialog
from calibre_plugins.list_switchboard.config import prefs

try:
  from calibre_plugins.list_switchboard.errors import (
    DuplicateStoredListsError, ImportCancelledError, ListSwitchboardError
  )
except ImportError:
  from errors import DuplicateStoredListsError, ImportCancelledError, ListSwitchboardError

try:
  from calibre_plugins.list_switchboard.goodreads import (
    GOODREADS_LOOKUP_DELAY_SECONDS, GoodreadsMixin
  )
except ImportError:
  from goodreads import GOODREADS_LOOKUP_DELAY_SECONDS, GoodreadsMixin

try:
  from calibre_plugins.list_switchboard.import_flow import (
    IMPORT_MATCH_PROGRESS_MAX, IMPORT_WRITE_PROGRESS_MAX, URL_FETCHER_PACKAGE,
    ImportFlowMixin,
  )
except ImportError:
  from import_flow import (
    IMPORT_MATCH_PROGRESS_MAX, IMPORT_WRITE_PROGRESS_MAX, URL_FETCHER_PACKAGE,
    ImportFlowMixin,
  )

try:
  from calibre_plugins.list_switchboard.matching import (
    MatchingMixin, clean_name, match_keys, normalize_key, normalize_match_text,
    series_match_keys, split_position_suffix, title_sort_without_article,
  )
except ImportError:
  from matching import (
    MatchingMixin, clean_name, match_keys, normalize_key, normalize_match_text,
    series_match_keys, split_position_suffix, title_sort_without_article,
  )

try:
  from calibre_plugins.list_switchboard.metadata import (
    MetadataMixin, format_list_entry, format_stored_lists, next_whole_index_after,
    parse_stored_lists, sort_names, unique_case_insensitive, validate_list_name,
  )
except ImportError:
  from metadata import (
    MetadataMixin, format_list_entry, format_stored_lists, next_whole_index_after,
    parse_stored_lists, sort_names, unique_case_insensitive, validate_list_name,
  )

try:
  from calibre_plugins.list_switchboard.list_state import ListStateMixin
except ImportError:
  from list_state import ListStateMixin

try:
  from calibre_plugins.list_switchboard.dialogs import DebugDialog
except ImportError:
  from dialogs import DebugDialog

try:
  from calibre.utils.browser import Browser as CalibreBrowser
except Exception:
  CalibreBrowser = None


ABOUT_TEXT = '''List Switchboard

A Calibre GUI plugin for managing an active reading list and stored alternate lists using configured metadata fields.

List Switchboard only edits the configured metadata fields. It does not delete, move, convert, or modify book files.'''

DEBUG_SECTIONS = (
  ('general', 'General'),
  ('metadata', 'Metadata state and cleanup'),
  ('selection', 'Book selection and series expansion'),
  ('writes', 'Metadata writes'),
  ('recipe', 'Recipe fetch and parsed output'),
  ('fallback', 'Fallback activity only'),
  ('import', 'Import matching and report'),
  ('goodreads', 'Goodreads lookups'),
  ('errors', 'Exceptions and tracebacks'),
)
class ListSwitchboardCore(ImportFlowMixin, ListStateMixin, MetadataMixin, GoodreadsMixin, MatchingMixin):

  def __init__(self, gui, do_user_config, plugin_base=None):
    self.gui = gui
    self.do_user_config = do_user_config
    self.plugin_base = plugin_base
    self.db = getattr(gui, 'current_db', None)
    self.goodreads_series_cache = {}
    self.last_goodreads_lookup_time = 0
    self.import_progress = None
    self.browser = None

  def debug_enabled(self, section='general'):
    if prefs.get('debug_logging', False):
      return True
    sections = prefs.get('debug_sections', {}) or {}
    return bool(sections.get(section, False))

  def debug_log(self, message, section='general'):
    if not self.debug_enabled(section):
      return
    print(f'List Switchboard [{section}]: {message}', flush=True)

  def debug_log_preview(self, label, text, limit=3000, section='general'):
    if not self.debug_enabled(section):
      return
    text = (text or '').replace('\r', '\\r').replace('\n', '\\n')
    if len(text) > limit:
      text = f'{text[:limit]}... <truncated {len(text) - limit} chars>'
    self.debug_log(f'{label}: {text}', section=section)

  def debug_metadata_helper_failed(self, field, err):
    self.debug_log(
      f'could not resolve series index field via Calibre helper for {field}: {err}',
      section='metadata')

  def debug_metadata_no_series_index_field(self, field):
    self.debug_log(f'no readable series index field found for {field}', section='metadata')

  def debug_metadata_formatted_read_failed(self, field, book_id, err):
    self.debug_log(
      f'formatted field read failed field={field} book_id={book_id}: {err}',
      section='metadata')

  def debug_metadata_preflight_store(self, book_id, raw_active, formatted_active, index_field, position):
    self.debug_log(
      f'preflight store book_id={book_id} raw_active={raw_active} '
      f'formatted_active={formatted_active} index_field={index_field} position={position}',
      section='metadata')

  def debug_metadata_library_state(self, active_field, stored_field):
    self.debug_log(
      f'configured fields active={active_field} stored={stored_field}',
      section='metadata')

  def debug_metadata_counts(self, active_counts, stored_names):
    self.debug_log(
      f'active counts={dict(active_counts)} stored={list(stored_names.values())}',
      section='metadata')

  def debug_metadata_repair_skipped(self):
    self.debug_log(
      'missing stored position repair skipped; no series index field',
      section='metadata')

  def debug_metadata_repaired_position(self, book_id, name, position):
    self.debug_log(
      f'repaired stored list position book_id={book_id} list={name} position={position}',
      section='metadata')

  def debug_selection_ids(self, ids):
    self.debug_log(f'selected book ids={ids}', section='selection')

  def debug_selection_expanded_series(self, ids, expanded):
    self.debug_log(f'expanded ids {ids} to series ids {sorted(expanded)}', section='selection')

  def debug_writes_store_active(self, book_id, active, raw_active, formatted_active, position):
    self.debug_log(
      f'storing active list book_id={book_id} active={active} raw_active={raw_active} '
      f'formatted_active={formatted_active} position={position}', section='writes')

  def debug_writes_active_field(self, count):
    self.debug_log(
      f'writing active field={prefs["active_list_field"]} count={count}',
      section='writes')

  def debug_writes_stored_field(self, count):
    self.debug_log(
      f'writing stored field={prefs["stored_lists_field"]} count={count}',
      section='writes')

  def debug_writes_finished(self, active_updates, stored_updates, changed):
    self.debug_log(
      f'wrote active_count={len(active_updates or {})} stored_count={len(stored_updates or {})} '
      f'changed_count={len(changed)}', section='writes')

  def debug_writes_active_series_field(self, field, label, active_updates, index_updates):
    self.debug_log(
      f'writing active series field={field} label={label} count={len(active_updates)} '
      f'index_count={len(index_updates or {})}', section='writes')

  def debug_recipe_start(self, recipe):
    self.debug_log(f'import recipe={recipe.NAME} url={recipe.URL}', section='recipe')

  def debug_recipe_fetch_url(self, url):
    self.debug_log(f'import fetch url={url}', section='recipe')

  def debug_recipe_fetched(self, url, html):
    self.debug_log(f'import fetched bytes={len(html)} from {url}', section='recipe')
    self.debug_log_preview('import fetched preview', html, section='recipe')

  def debug_recipe_failed(self, url, err):
    self.debug_log(f'recipe fetch/parse failed for {url}: {err}', section='recipe')

  def debug_fallback_urls(self, url, urls):
    self.debug_log(f'fallback fetch urls for {url}: {urls}', section='fallback')

  def debug_fallback_urllib_fetch(self, url):
    self.debug_log(f'fallback urllib fetch url={url}', section='fallback')

  def debug_recipe_linked_page_failed(self, url, err, entry):
    title = entry.get('title', '') if entry else ''
    self.debug_log(
      f'recipe linked page failed title={title} url={url}: {err}',
      section='recipe')

  def debug_parser_message(self, message):
    self.debug_log(message, section='recipe')

  def debug_recipe_output(self, parsed):
    entries = parsed.get('entries') or []
    self.debug_log(
      f'recipe output name={parsed.get("name", "")} url={parsed.get("url", "")} entries={len(entries)}',
      section='recipe')
    for index, entry in enumerate(entries[:25], start=1):
      self.debug_log(f'recipe entry {index}: {entry}', section='recipe')
    if len(entries) > 25:
      self.debug_log(
        f'recipe entry log truncated; {len(entries) - 25} additional entries',
        section='recipe')

  def debug_import_target(self, list_name, active):
    self.debug_log(f'import target list={list_name} current active={active}', section='import')

  def debug_import_summary(self, matched, missing_entries, entries):
    self.debug_log(
      f'import matched books={len(matched)} missing entries={len(missing_entries)} '
      f'of entries={len(entries)}', section='import')

  def debug_import_missing_entries(self, missing_entries):
    for index, entry in enumerate(missing_entries[:50], start=1):
      self.debug_log(f'import missing entry {index}: {entry}', section='import')
    if len(missing_entries) > 50:
      self.debug_log(
        f'import missing entry log truncated; {len(missing_entries) - 50} additional entries',
        section='import')

  def debug_import_empty_entry(self, entry):
    self.debug_log(f'import skipped empty title entry={entry}', section='import')

  def debug_import_match_entry(self, entry, candidates):
    self.debug_log(
      f'import match entry position={entry.get("position", "")} title={entry.get("title", "")} '
      f'aliases={entry.get("aliases", [])} author={entry.get("author", "")} candidates={candidates}',
      section='import')

  def debug_import_matched_book(self, label, book_id, entry, titles, series):
    self.debug_log(
      f'import {label} book_id={book_id} position={entry.get("position", "")} '
      f'title={titles.get(book_id, "")} series={series.get(book_id, "")}',
      section='import')

  def debug_exception(self):
    if not self.debug_enabled('errors'):
      return
    self.debug_log('exception', section='errors')
    for line in traceback.format_exc().rstrip().splitlines():
      self.debug_log(line, section='errors')

  def debug_general_status_message(self, message):
    self.debug_log(message, section='general')

  def configured(self):
    if not (prefs['active_list_field'] and prefs['stored_lists_field']
        and prefs['active_list_field'] != prefs['stored_lists_field']):
      return False
    try:
      return self.active_field_is_series() and self.supported_stored_field()
    except Exception:
      return False

  def ensure_configured(self):
    if self.configured():
      return True
    self.do_user_config(parent=self.gui)
    return self.configured()

  def selected_book_ids(self):
    rows = self.gui.library_view.selectionModel().selectedRows()
    return list(map(self.gui.library_view.model().id, rows or []))

  def current_book_id(self):
    index = self.gui.library_view.currentIndex()
    if not index.isValid():
      return None
    try:
      return self.gui.library_view.model().id(index)
    except Exception:
      return None

  def all_book_ids(self):
    return list(self.db.new_api.all_book_ids())

  def select_book_ids(self, ids, message):
    ids = sorted(set(ids))
    if not ids:
      self.status_message(message)
      return
    keep_current = self.current_book_id() in ids
    self.gui.library_view.select_rows(
      ids,
      using_ids=True,
      change_current=not keep_current,
      scroll=not keep_current)
    self.status_message(message)

  def display_authors(self, authors):
    if authors is None:
      return ''
    if isinstance(authors, (list, tuple)):
      return ', '.join(str(author) for author in authors)
    return str(authors)

  def fetch_url(self, url):
    headers = {
      'User-Agent': (
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/124.0.0.0 Safari/537.36'
      ),
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Connection': 'close',
    }
    if CalibreBrowser is not None:
      browser = self.calibre_browser(headers)
      response = browser.open(url, timeout=30)
      charset = response.headers.get_content_charset() or 'utf-8'
      return response.read().decode(charset, 'replace')
    self.debug_fallback_urllib_fetch(url)
    request = Request(url, headers=headers)
    with urlopen(request, timeout=30) as response:
      charset = response.headers.get_content_charset() or 'utf-8'
      return response.read().decode(charset, 'replace')

  def calibre_browser(self, headers):
    if self.browser is None:
      self.browser = CalibreBrowser()
      try:
        self.browser.set_handle_robots(False)
      except Exception:
        pass
    self.browser.addheaders = list(headers.items())
    return self.browser

  def fallback_fetch_urls(self, url):
    for fetcher in self.available_import_recipes():
      urls = fetcher.fallback_urls(url) if hasattr(fetcher, 'fallback_urls') else ()
      if urls:
        self.debug_fallback_urls(url, urls)
        return urls
    return ()

  def sleep_with_events(self, seconds, message):
    end_time = time.time() + max(0, seconds)
    while time.time() < end_time:
      self.update_import_progress(message=message)
      time.sleep(min(0.1, max(0, end_time - time.time())))

  def import_entry_keys(self, entry):
    names = [entry.get('title', '')]
    aliases = entry.get('aliases') or []
    if isinstance(aliases, str):
      aliases = [aliases]
    names.extend(aliases)
    keys = []
    for name in names:
      for key in match_keys(name):
        if key and key not in keys:
          keys.append(key)
    return keys

  def status_message(self, message):
    status_bar = getattr(self.gui, 'status_bar', None)
    if hasattr(status_bar, 'show_message'):
      status_bar.show_message(message, 5000)
    elif hasattr(status_bar, 'showMessage'):
      status_bar.showMessage(message, 5000)
    else:
      self.debug_general_status_message(message)

  def refresh_books(self, ids):
    if not ids:
      return
    model = self.gui.library_view.model()
    model.refresh_ids(list(ids))
    try:
      self.gui.tags_view.recount()
    except Exception:
      pass

  def show_debug_dialog(self):
    d = DebugDialog(self.gui, DEBUG_SECTIONS)
    if d.exec() != QDialog.Accepted:
      return
    prefs['debug_logging'] = bool(d.debug_logging.isChecked())
    prefs['debug_sections'] = {
      key: bool(box.isChecked())
      for key, box in d.section_boxes.items()
    }
    if prefs['debug_logging']:
      self.status_message('List Switchboard debug logging is on for all sections.')
    else:
      enabled = [label for key, label in DEBUG_SECTIONS if prefs['debug_sections'].get(key)]
      if enabled:
        self.status_message(f'List Switchboard debug logging is on for: {", ".join(enabled)}.')
      else:
        self.status_message('List Switchboard debug logging is off.')

  def set_include_calibre_series(self, enabled):
    prefs['include_calibre_series'] = bool(enabled)
    state = 'on' if prefs['include_calibre_series'] else 'off'
    self.status_message(f'Include series when adding is {state}.')

  def show_about(self):
    QMessageBox.about(self.gui, 'About List Switchboard', ABOUT_TEXT)

  def show_exception(self, title, err):
    self.debug_exception()
    error_dialog(self.gui, title, str(err), show=True)
