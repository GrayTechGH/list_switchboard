# Local Agent Notes

This file is local-only. It is excluded through `.git/info/exclude` and should not be committed or uploaded with the repository.

## Local Docs Reference

Check the local `_docs/` files before making broad changes or continuing an older thread:

- `_docs/PROJECT_CONTEXT.md`: project purpose, current architecture direction, editing habits, and test command reminders.
- `_docs/ARCHITECTURE.md`: current module and mixin responsibilities, import-cache behavior, saved match behavior, and award import patterns.
- `_docs/DECISIONS.md`: durable local decisions about refactors, testing, import recipes, award sources, and documentation style.
- `_docs/PLANS.md`: near-term stabilization and refactor plans, testing plan, import recipe plan, and documentation plan.
- `_docs/TASKS.md`: current todo list and implementation-order groupings.
- `_docs/CODEX_HANDOFF.md`: preferred commands, recent passing test state, sandbox notes, dirty-tree expectations, and local-only doc notes.

When implementing an accepted plan, update the relevant local docs before finishing if the work changes project state, architecture, durable decisions, task status, command/test expectations, registry counts, or handoff notes. Prefer concise updates in `_docs/` and keep them grounded in files that actually changed.

Current code snapshot:

- `main.py` is the Calibre-facing facade. Most behavior lives in subsystem mixins.
- Built-in imports are URL fetchers, registered in `url_fetcher/__init__.py`; the current registry contains 143 fetchers.
- Parser classes inherit from `ListParserBase` directly or through a family base such as `SFADBParser`.
- URL fetchers should create/configure parser instances and delegate parser-facing methods through `parser()` and `get_filter_list()`.
- File-backed import data lives under Calibre config as flat `import_<list_id>.json` and `match_<list_id>.json` files.

## Calibre Plugin Conventions

Prefer Calibre's plugin APIs, bundled third-party libraries, and conventions over generic Python or Qt patterns when Calibre provides an appropriate tool.

Use Calibre-facing APIs at plugin boundaries, including:

- `calibre.gui2` dialogs such as `error_dialog` and `question_dialog` for user-facing messages.
- `qt.core` imports instead of direct PyQt or PySide imports.
- `calibre.utils.config.JSONConfig` for plugin preferences.
- `calibre_plugins.list_switchboard...` imports inside plugin code.
- `InterfaceActionBase` and `InterfaceAction` for plugin lifecycle and UI integration.

When a third-party library is bundled with Calibre, treat it as part of the preferred Calibre runtime toolset for plugin code. This includes common parsing and import helpers such as `beautifulsoup4`, `lxml`, `html5-parser`, `html5lib`, `css-parser`, `html2text`, `Markdown`, `feedparser`, `mechanize`, and `python-dateutil` when they fit the source shape better than standard-library tools.

Plain Python remains appropriate for focused domain code such as custom exceptions, parser helpers, normalization logic, and other modules that do not need Calibre integration.

## Comment And Documentation Style

Use comments to document constraints that are easy to break during refactors, not to narrate obvious code.

Prefer these headings in module or class docstrings when they genuinely help:

- `Maintenance notes`
- `Type constraints`
- `Invariants`
- `Refactor warning`

Avoid labels such as `AGENT_HINT` or `AGENT_TELEMETRY`. They are noisy in normal source files and do not describe runtime behavior.

## When To Add Documentation

Add module or class documentation when code depends on:

- Calibre API behavior that is not obvious from the call site.
- Mixin ordering or cross-mixin method availability.
- Parser input shapes that vary across HTML, markdown, plain text, JSON, XML, or wikitext.
- Progress counters where the denominator must match real writes.
- Matching or normalization rules where a simpler-looking change would broaden or narrow matches.

Use inline comments for load-bearing details only:

- A line looks inefficient but protects a known edge case.
- A parser workaround handles a specific malformed source shape.
- A fallback order is intentional because earlier options preserve more information.

## When Not To Add Documentation

Do not add comments that merely restate the code.

Avoid broad claims like:

- "This simply handles..."
- "This easily manages..."
- "Optimize this later..."

Do not add complexity notes unless the logic is dense, performance-sensitive, or likely to be mistaken during refactoring.

## Parser-Specific Notes

Parser comments should explain:

- The accepted source shapes.
- The schema contract.
- Why fallback parsers run in a specific order.
- Which rows are intentionally rejected.
- Which failures should produce empty results or notes instead of aborting imports.

For parser code, prefer documentation near the boundary function and concise comments near load-bearing transformations.

For HTML parser code, navigate the document structurally with BeautifulSoup or another Calibre-bundled parser before using regex:

- Use `find`, `find_all`, sibling/parent traversal, table cell access, and tag text extraction to narrow the source to a specific row, list item, paragraph, heading, or section.
- Use regex only after parser navigation has isolated a small text fragment whose internal format is the thing being parsed.
- Do not use broad regex or raw string splitting over whole HTML pages when Soup navigation can identify the relevant source boundary.
- Decode fetched HTML bytes before parser logic with BeautifulSoup's decoding support, such as `UnicodeDammit`, when charset handling is ambiguous.

Award import parsers now mostly follow two shapes:

- Category-based SFADB year pages: discover year links from an overview page, parse one configured category per fetcher, and share winner/nominee positioning.
- Single-category award pages: discover year links from an overview page and parse named sections such as `Winner`, `Shortlist`, `Finalists`, or `Special Citation`.
- Source-specific table pages when SFADB is unavailable: parse the stable table shape directly, keep official fallback parsing narrow, and preserve the same output entry schema.
- Official history pages with source-specific boundaries, such as Hugo Novel: parse the official entries, use fallback sources only for narrow corrections, and add regression tests for section boundaries.

When adding award recipes:

- Prefer SFADB when it has complete stable year pages matching existing parsers.
- Use non-SFADB sources only when SFADB is unavailable or unsuitable; document the chosen shape in the parser module.
- Keep one parser module shared by related category recipes.
- Set `match_series = False` unless the source is intentionally a series/list source.
- Preserve author suffixes such as `Jr.`; do not let a trailing suffix become the whole author after comma splitting.
- Strip publisher/publication parentheticals and bracketed notes from matchable title/author text.
- For Hugo Novel, keep `Short Fiction`, `Short Story`, `Novella`, and similar section labels as category boundaries so short fiction is not imported as Best Novel.
- Register new fetchers in `url_fetcher/__init__.py` near related award imports and add recipe-order tests.
- Add focused fixture tests in `_dev_tools/test_import_matching.py` for parser behavior, fetcher flow, and registration order.

## Mixin-Specific Notes

For mixins, document:

- What the mixin owns.
- Which methods or attributes it expects from `ListSwitchboardCore` or sibling mixins.
- State invariants that must survive UI operations and import flows.
- Refactor warnings around Calibre field writes, progress accounting, and Goodreads fallback behavior.

Keep `ListSwitchboardCore` as the Calibre-facing facade. New behavior should usually land in a focused module or mixin unless it is truly facade glue.

## Storage And Import Cache Notes

File-backed import data belongs directly under Calibre's user config `list_switchboard` directory. Use flat filenames:

- `import_<list_id>.json` for parsed imported-list cache data.
- `match_<list_id>.json` for saved match overrides.

Do not add nested cache folders unless the storage shape is deliberately redesigned. Import cache files should store parsed entries and small append bookkeeping, not raw fetched HTML/API pages.

Saved match overrides are for non-obvious matches only. Do not persist every automatic title/series match; direct matches should be recomputed from the current Calibre library during each import.
