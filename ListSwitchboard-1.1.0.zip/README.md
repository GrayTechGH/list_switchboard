# Local Session Notes

This is a local-only orientation file for future Codex sessions working on List Switchboard.
It is intentionally excluded from Git through `.git/info/exclude`.

Useful files:

- `_docs/PROJECT_CONTEXT.md`: what the plugin does and what matters when editing it.
- `_docs/ARCHITECTURE.md`: current module split and mixin responsibilities.
- `_docs/DECISIONS.md`: project decisions made during the refactor.
- `_docs/TASKS.md`: completed and likely next tasks.
- `_docs/CODEX_HANDOFF.md`: commands, caveats, and handoff notes.
- `_docs/PLANS.md`: possible future refactor/testing plans.

Preferred Python for this project is 3.12:

```powershell
.\.venv\Scripts\python.exe ...
```

Do not assume unrelated dirty Git changes belong to the current task. Inspect first, then preserve user work.

Current import UI uses a searchable `Import List...` chooser instead of a per-recipe submenu. Award imports are implemented as URL fetchers plus parser modules, with SFADB-backed award sources following the shared overview/year-page pattern.
