"""Packaged parser data files."""
